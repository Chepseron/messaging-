/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BEAN;

import com.amon.db.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import javax.faces.context.FacesContext;
import javax.persistence.EntityManager;

import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;
import org.apache.commons.lang3.StringUtils;
import org.primefaces.model.chart.Axis;
import org.primefaces.model.chart.AxisType;
import org.primefaces.model.chart.CategoryAxis;
import org.primefaces.model.chart.LineChartModel;
import org.primefaces.model.chart.LineChartSeries;

/**
 *
 * @author amon.sabul
 */
@SessionScoped
@ManagedBean(name = "acc")

public class acc implements Serializable {

    @PersistenceContext(unitName = "accPU")
    private EntityManager em;
    @Resource
    private UserTransaction utx;

    private Usergroup group1 = new Usergroup();
    private List<Usergroup> group1List = new ArrayList<Usergroup>();
    private User user = new User();
    private List<User> userList = new ArrayList<User>();
    private Status status = new Status();
    private boolean remember;
    private List<Status> statusList = new ArrayList<Status>();
    private Audit audit = new Audit();
    private List<Audit> auditList = new ArrayList<Audit>();
    private Accident accident = new Accident();
    private List<Accident> accidentList = new ArrayList<Accident>();
    private Actors actors = new Actors();
    private List<Actors> actorsList = new ArrayList<Actors>();
    private Deployment deployment = new Deployment();
    private List<Deployment> deploymentList = new ArrayList<Deployment>();
    private Deploymentunit deploymentunit = new Deploymentunit();
    private List<Deploymentunit> deploymentunitList = new ArrayList<Deploymentunit>();
    private List<String> responsibilities;
    private List<String> deploymentUnitID;
    private String username = new String();
    private String password = new String();
    private Long accidentListCount;

    /**
     * Creates a new instance of acc
     */
    public acc() {
    }

    @PostConstruct
    public void init() {
        try {
            createAccidentModel();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private LineChartModel accidentModel;

    private void createAccidentModel() {
        accidentList = em.createQuery("select a from Accident a").getResultList();
        setAccidentModel(new LineChartModel());
        LineChartSeries Cohort = new LineChartSeries();
        Cohort.setFill(true);
        Cohort.setLabel("Accident/places occured");

        for (Accident med : accidentList) {
            Cohort.set(med.getRoad(), med.getDeadVictims());
        }

        getAccidentModel().addSeries(Cohort);
        getAccidentModel().setTitle("Accident");
        getAccidentModel().setLegendPosition("ne");
        getAccidentModel().setStacked(true);
        getAccidentModel().setShowPointLabels(true);

        Axis xAxis = new CategoryAxis("Places/Road occured");
        getAccidentModel().getAxes().put(AxisType.X, xAxis);
        Axis yAxis = getAccidentModel().getAxis(AxisType.Y);
        yAxis.setLabel("Accidents and places occured");
        yAxis.setMin(0);

    }

    public String login() {
        try {
            if (StringUtils.isEmpty(getUsername())) {
                FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "!ERROR!", "Please login to the system");
                FacesContext context = FacesContext.getCurrentInstance();
                context.addMessage("loginInfoMessages", message);
                return "/index.xhtml";
            }
            setUser((User) getEm().createQuery("select u from User u where u.username = '" + getUsername() + "' and u.pword = '" + getPassword() + "'").getSingleResult());
            // setGrouplist(getEm().createQuery("select g from Usergroups g where g.name = '" + getUser().getGroupID().getName() + "'").getResultList());
            getUtx().begin();
            getAudit().setAction("logged into the system at  " + new Date());
            getAudit().setCreatedby(user.getIdusers());
            getAudit().setTimer(new Date());
            getEm().persist(getAudit());
            getUtx().commit();

            return "index2.xhtml?faces-redirect=true";
        } catch (Exception e) {
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "!ERROR!", "Please provide correct credentials");
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage("loginInfoMessages", message);
            e.printStackTrace();
        }
        return null;
    }

    public String logout() {
        FacesContext context = FacesContext.getCurrentInstance();
        context.getAttributes().clear();
        return "/index.xhtml?faces-redirect=true";
    }

    public String createDeployment() {
        try {
            if (StringUtils.isEmpty(getUsername())) {

                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Warning!", "Please login to the system"));
                return "/index.xhtml";
            }

            StringBuilder units = new StringBuilder();
            for (String str : deploymentUnitID) {
                units.append(str);

            }
            deployment.setDeploymentUnitID(units.toString());
            deployment.setCreatedOn(new java.util.Date());
            deployment.setCreatedBy(user);

            System.out.println(deployment.getAccident());
            System.out.println(deployment.getActors1Number());
            System.out.println(deployment.getActors2Number());
            System.out.println(deployment.getActors3Number());
            System.out.println(deployment.getCreatedBy());
            System.out.println(deployment.getDeploymentUnitID());
            System.out.println(deployment.getCreatedOn());
            System.out.println(deployment.getSeverity());
            System.out.println(deployment.getStatusID());
            getUtx().begin();
            getAudit().setAction("created deployment");
            getAudit().setCreatedby(getUser().getIdusers());
            getAudit().setTimer(new Date());
            getEm().persist(getAudit());
            getEm().persist(getDeployment());
            getUtx().commit();

            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Success!", getDeployment().getDeploymentUnitID() + " saved successfully."));
            setDeployment(new Deployment());
        } catch (Exception ex) {
            ex.printStackTrace();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!", ex.getMessage()));
        }
        setDeployment(new Deployment());
        return null;
    }

    public String updateDeployment() {
        try {
            if (StringUtils.isEmpty(getUsername())) {
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Warning!", "Please login to the system"));
                return "/index.xhtml";
            }
            Deployment deployment = getEm().find(Deployment.class, getDeployment().getIddeployment());

            getUtx().begin();
            getAudit().setAction("updated deployment");
            getAudit().setCreatedby(getUser().getIdusers());
            getAudit().setTimer(new Date());
            getEm().persist(getAudit());
            getEm().merge(deployment);
            getUtx().commit();
            deployment = new Deployment();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Success!", deployment.getDeploymentUnitID() + " Updated successfully."));
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!", "Could not update a deployment unit."));
        }
        setDeployment(new Deployment());
        return null;
    }

    public String deleteDeployment(Deployment deployment) {
        try {
            if (StringUtils.isEmpty(getUsername())) {

                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Warning!", "Please login to the system"));
                return "/index.xhtml";
            }
            getUtx().begin();
            getAudit().setAction("Deleted deployment");
            getAudit().setCreatedby(getUser().getIdusers());
            getAudit().setTimer(new Date());
            getEm().persist(getAudit());
            Deployment toBeRemoved = (Deployment) getEm().merge(deployment);
            getEm().remove(toBeRemoved);
            getUtx().commit();
            deployment = new Deployment();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Success!", deployment.getDeploymentUnitID() + " Deleted successfully."));

            return null;
        } catch (Exception e) {
            e.printStackTrace();

            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Success!", deployment.getDeploymentUnitID() + " failed to delete successfully."));
        }
        deployment = new Deployment();
        return null;
    }

    public boolean isRemember() {
        return this.remember;
    }

    public void setRemember(boolean remember) {
        this.remember = remember;
    }

    public String createDeploymentunit() {
        try {
            if (StringUtils.isEmpty(getUsername())) {

                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Warning!", "Please login to the system"));
                return "/index.xhtml";
            }
            getUtx().begin();
            getAudit().setAction("created deployment unit");
            getAudit().setCreatedby(getUser().getIdusers());
            getAudit().setTimer(new Date());
            deploymentunit.setCreatedBy(user);
            deploymentunit.setDateCreated(new java.util.Date());
            getEm().persist(getAudit());
            getEm().persist(getDeploymentunit());
            getUtx().commit();

            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Success!", deploymentunit.getOrgname() + " saved successfully."));
            setDeploymentunit(new Deploymentunit());
        } catch (Exception ex) {
            ex.printStackTrace();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!", ex.getMessage()));
        }
        setDeploymentunit(new Deploymentunit());
        return null;
    }

    public String updateDeploymentunit() {
        try {
            if (StringUtils.isEmpty(getUsername())) {

                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Warning!", "Please login to the system"));
                return "/index.xhtml";
            }
            Deploymentunit deployment = getEm().find(Deploymentunit.class, getDeploymentunit().getIddeploymentUnit());
            getUtx().begin();
            getAudit().setAction("updated deployment unit");
            getAudit().setCreatedby(getUser().getIdusers());
            getAudit().setTimer(new Date());
            getEm().persist(getAudit());
            getEm().merge(deployment);
            getUtx().commit();
            deployment = new Deploymentunit();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Success!", deployment.getOrgname() + " Updated successfully."));
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!", "Could not update a deployment."));
        }
        setDeploymentunit(new Deploymentunit());
        return null;
    }

    public String deleteDeploymentunit(Deploymentunit deployment) {
        try {
            if (StringUtils.isEmpty(getUsername())) {

                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Warning!", "Please login to the system"));
                return "/index.xhtml";
            }
            getUtx().begin();
            getAudit().setAction("Deleted deployment unit");
            getAudit().setCreatedby(getUser().getIdusers());
            getAudit().setTimer(new Date());
            getEm().persist(getAudit());
            Deploymentunit toBeRemoved = (Deploymentunit) getEm().merge(deployment);
            getEm().remove(toBeRemoved);
            getUtx().commit();
            deployment = new Deploymentunit();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Success!", deployment.getOrgname() + " Deleted successfully."));

            return null;
        } catch (Exception e) {
            e.printStackTrace();

            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Success!", deployment.getOrgname() + " failed to delete successfully."));
        }
        deployment = new Deploymentunit();
        return null;
    }

    //group
    public String createActors() {
        try {
            if (StringUtils.isEmpty(getUsername())) {

                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Warning!", "Please login to the system"));
                return "/index.xhtml";
            }
            getUtx().begin();
            getAudit().setAction("created actors");
            getAudit().setCreatedby(getUser().getIdusers());
            getAudit().setTimer(new Date());
            actors.setCreatedBy(user);
            actors.setDateCreated(new java.util.Date());
            getEm().persist(getAudit());
            getEm().persist(getActors());
            getUtx().commit();

            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Success!", getActors().getNames() + " saved successfully."));
            setActors(new Actors());
        } catch (Exception ex) {
            ex.printStackTrace();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!", ex.getMessage()));
        }
        setActors(new Actors());
        return null;
    }

    public String updateActors() {
        try {
            if (StringUtils.isEmpty(getUsername())) {

                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Warning!", "Please login to the system"));
                return "/index.xhtml";
            }
            Actors actors = getEm().find(Actors.class, getActors().getIdactors());
            getUtx().begin();
            getAudit().setAction("updated actors");
            getAudit().setCreatedby(getUser().getIdusers());
            getAudit().setTimer(new Date());
            actors.setCreatedBy(user);
            getEm().persist(getAudit());
            getEm().merge(actors);
            getUtx().commit();
            actors = new Actors();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Success!", actors.getNames() + " Updated successfully."));
        } catch (Exception ex) {
            ex.printStackTrace();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!", "Could not update an actor."));
        }
        setActors(new Actors());
        return null;
    }

    public String deleteActors(Actors actors) {
        try {
            if (StringUtils.isEmpty(getUsername())) {

                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Warning!", "Please login to the system"));
                return "/index.xhtml";
            }
            getUtx().begin();
            getAudit().setAction("Deleted actors");
            getAudit().setCreatedby(getUser().getIdusers());
            getAudit().setTimer(new Date());
            getEm().persist(getAudit());
            Actors toBeRemoved = (Actors) getEm().merge(actors);
            getEm().remove(toBeRemoved);
            getUtx().commit();
            actors = new Actors();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Success!", actors.getNames() + " Deleted successfully."));

            return null;
        } catch (Exception e) {
            e.printStackTrace();

            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Success!", actors.getNames() + " failed to delete successfully."));
        }
        actors = new Actors();
        return null;
    }

    public String createUsergroup() {
        try {
            if (StringUtils.isEmpty(getUsername())) {

                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Warning!", "Please login to the system"));
                return "/index.xhtml";
            }
            for (String str : responsibilities) {
                group1.setResponsibilities(str);
                getUtx().begin();
                getAudit().setAction("created group");
                getAudit().setCreatedby(getUser().getIdusers());
                getAudit().setTimer(new Date());
                group1.setCreatedBy(user);
                group1.setCreatedAt(new java.util.Date());
                getEm().persist(getAudit());
                getEm().persist(group1);
                getUtx().commit();
            }

            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Success!", getUsergroup().getName() + " saved successfully."));
            setUsergroup(new Usergroup());
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!", ex.getMessage()));
        }
        setUsergroup(new Usergroup());
        return null;
    }

    public String updateUsergroup() {
        try {
            if (StringUtils.isEmpty(getUsername())) {

                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Warning!", "Please login to the system"));
                return "/index.xhtml";
            }
            Usergroup group2 = getEm().find(Usergroup.class, getUsergroup().getIdgroups());
            getUtx().begin();
            getAudit().setAction("updated group");
            getAudit().setCreatedby(getUser().getIdusers());
            getAudit().setTimer(new Date());
            getEm().persist(getAudit());
            getEm().merge(group2);
            getUtx().commit();
            group2 = new Usergroup();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Success!", group2.getName() + " Updated successfully."));
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!", "Could not update a group."));
        }
        setUsergroup(new Usergroup());
        return null;
    }

    public String deleteUsergroup(Usergroup group) {
        try {
            if (StringUtils.isEmpty(getUsername())) {

                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Warning!", "Please login to the system"));
                return "/index.xhtml";
            }
            getUtx().begin();
            getAudit().setAction("Deleted group");
            getAudit().setCreatedby(getUser().getIdusers());
            getAudit().setTimer(new Date());
            getEm().persist(getAudit());
            Usergroup toBeRemoved = (Usergroup) getEm().merge(group);
            getEm().remove(toBeRemoved);
            getUtx().commit();
            group = new Usergroup();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Success!", group.getName() + " Deleted successfully."));

            return null;
        } catch (Exception e) {
            e.printStackTrace();

            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Success!", group.getName() + " failed to delete successfully."));
        }
        group = new Usergroup();
        return null;
    }

    public String createUser() {
        try {
            if (StringUtils.isEmpty(getUsername())) {

                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Warning!", "Please login to the system"));
                return "/index.xhtml";
            }
            user.setCreatedAt(new java.util.Date());
            user.setCreatedBy(user);
            getUtx().begin();
            getAudit().setAction("saved user " + getUser().getUsername());
            getAudit().setCreatedby(getUser().getIdusers());
            getAudit().setTimer(new Date());
            getEm().persist(getAudit());
            getEm().persist(getUser());
            getUtx().commit();

            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Success!", getUser().getName() + " saved successfully."));
            setUser(new User());
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!", ex.getMessage()));
        }
        setUser(new User());
        return null;
    }

    public String updateUser() {
        try {
            if (StringUtils.isEmpty(getUsername())) {

                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Warning!", "Please login to the system"));
                return "/index.xhtml";
            }
            User user = getEm().find(User.class, getUser().getIdusers());
            getUtx().begin();
            getAudit().setAction("updated user " + user.getIdusers());
            getAudit().setCreatedby(user.getIdusers());
            getAudit().setTimer(new Date());
            getEm().persist(getAudit());
            getEm().merge(user);
            getUtx().commit();
            user = new User();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Success!", user.getName() + " Updated successfully."));
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!", "Could not update a user."));
        }
        setUser(new User());
        return null;
    }

    public String deleteUser(User user) {
        try {
            if (StringUtils.isEmpty(getUsername())) {

                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Warning!", "Please login to the system"));
                return "/index.xhtml";
            }
            getUtx().begin();
            getAudit().setAction("Deleted user");
            getAudit().setCreatedby(user.getIdusers());
            getAudit().setTimer(new Date());
            getEm().persist(getAudit());
            User toBeRemoved = (User) getEm().merge(user);
            getEm().remove(toBeRemoved);
            getUtx().commit();
            user = new User();
            FacesMessage success = new FacesMessage(FacesMessage.SEVERITY_ERROR, "User deleted", "User deleted");
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage("User", success);

            return null;
        } catch (Exception e) {
            e.printStackTrace();

            FacesMessage success = new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), e.getMessage());
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage("User", success);
        }
        user = new User();
        return null;
    }

    public String createAccident() {
        try {
            if (StringUtils.isEmpty(getUsername())) {

                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Warning!", "Please login to the system"));
                return "/index.xhtml";
            }
            accident.setTimeOccured(new java.util.Date());
            getUtx().begin();
            getAudit().setAction("saved accident " + getAccident().getPlaceOccured() + getAccident().getRoad());
            getAudit().setCreatedby(getUser().getIdusers());
            getAudit().setTimer(new Date());
            getEm().persist(getAudit());
            getEm().persist(getAccident());
            getUtx().commit();

            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Success!", getAccident().getRoad() + " saved successfully."));
            setAccident(new Accident());
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!", ex.getMessage()));
        }
        setAccident(new Accident());
        return null;
    }

    public String updateAccident() {
        try {
            if (StringUtils.isEmpty(getUsername())) {

                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Warning!", "Please login to the system"));
                return "/index.xhtml";
            }
            Accident accid = getEm().find(Accident.class, getAccident().getIdaccident());
            getUtx().begin();
            getAudit().setAction("updated accident " + accid.getPlaceOccured() + " " + accid.getRoad());
            getAudit().setCreatedby(getUser().getIdusers());
            getAudit().setTimer(new Date());
            getEm().persist(getAudit());
            getEm().merge(accid);
            getUtx().commit();
            accid = new Accident();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Success!", accid.getPlaceOccured() + " " + accid.getRoad() + " Updated successfully."));
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!", "Could not update an accident."));
        }
        setAccident(new Accident());
        return null;
    }

    public String deleteAccident(Accident accid) {
        try {
            if (StringUtils.isEmpty(getUsername())) {

                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Warning!", "Please login to the system"));
                return "/index.xhtml";
            }
            getUtx().begin();
            getAudit().setAction("Deleted accident");
            getAudit().setCreatedby(getUser().getIdusers());
            getAudit().setTimer(new Date());
            getEm().persist(getAudit());
            Accident toBeRemoved = (Accident) getEm().merge(accid);
            getEm().remove(toBeRemoved);
            getUtx().commit();
            accid = new Accident();
            FacesMessage success = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Accident deleted", "Accident deleted");
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage("Accident", success);

            return null;
        } catch (Exception e) {
            e.printStackTrace();

            FacesMessage success = new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), e.getMessage());
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage("Accident", success);
        }
        accid = new Accident();
        return null;
    }

    public String createStatus() {
        try {
            if (StringUtils.isEmpty(getUsername())) {

                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Warning!", "Please login to the system"));
                return "/index.xhtml";
            }
            status.setCreatedBy(user);
            getUtx().begin();
            getAudit().setAction("created status");
            getAudit().setCreatedby(getUser().getIdusers());
            getAudit().setTimer(new Date());
            getEm().persist(getAudit());
            getEm().persist(getStatus());
            getUtx().commit();

            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Success!", status.getName() + " saved successfully."));
            setStatus(new Status());
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!", ex.getMessage()));
        }
        setStatus(new Status());
        return null;
    }

    public String updateStatus() {
        try {
            if (StringUtils.isEmpty(getUsername())) {

                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Warning!", "Please login to the system"));
                return "/index.xhtml";
            }
            Status status = getEm().find(Status.class, getStatus().getIdstatus());
            getUtx().begin();
            getAudit().setAction("updated segment");
            getAudit().setCreatedby(getUser().getIdusers());
            getAudit().setTimer(new Date());
            getEm().persist(getAudit());
            getEm().merge(status);
            getUtx().commit();
            status = new Status();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Success!", status.getName() + " Updated successfully."));
        } catch (Exception ex) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!", "Could not update a status."));
        }
        setStatus(new Status());
        return null;
    }

    public String deleteStatus(Status status) {
        try {
            if (StringUtils.isEmpty(getUsername())) {

                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Warning!", "Please login to the system"));
                return "/index.xhtml";
            }
            getUtx().begin();
            getAudit().setAction("Deleted status");
            getAudit().setCreatedby(getUser().getIdusers());
            getAudit().setTimer(new Date());
            getEm().persist(getAudit());
            Status toBeRemoved = (Status) getEm().merge(status);
            getEm().remove(toBeRemoved);
            getUtx().commit();
            status = new Status();
            FacesMessage success = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Status deleted", "Status deleted");
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage("Status", success);

            return null;
        } catch (Exception e) {
            e.printStackTrace();

            FacesMessage success = new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), e.getMessage());
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage("Status", success);
        }
        status = new Status();
        return null;
    }

    /**
     * @return the em
     */
    public EntityManager getEm() {
        return em;
    }

    /**
     * @param em the em to set
     */
    public void setEm(EntityManager em) {
        this.em = em;
    }

    /**
     * @return the utx
     */
    public javax.transaction.UserTransaction getUtx() {
        return utx;
    }

    /**
     * @param utx the utx to set
     */
    public void setUtx(javax.transaction.UserTransaction utx) {
        this.utx = utx;
    }

    /**
     * @return the group1
     */
    public Usergroup getUsergroup() {
        return group1;
    }

    /**
     * @param group1 the group1 to set
     */
    public void setUsergroup(Usergroup group1) {
        this.group1 = group1;
    }

    /**
     * @return the group1List
     */
    public List<Usergroup> getUsergroupList() {
        group1List = em.createQuery("select g from Usergroup g").getResultList();
        return group1List;
    }

    /**
     * @param group1List the group1List to set
     */
    public void setUsergroupList(List<Usergroup> group1List) {
        this.group1List = group1List;
    }

    /**
     * @return the user
     */
    public User getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(User user) {
        this.user = user;
    }

    /**
     * @return the userList
     */
    public List<User> getUserList() {
        userList = em.createQuery("select u from User u").getResultList();
        return userList;
    }

    /**
     * @param userList the userList to set
     */
    public void setUserList(List<User> userList) {
        this.userList = userList;
    }

    /**
     * @return the status
     */
    public Status getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(Status status) {
        this.status = status;
    }

    /**
     * @return the statusList
     */
    public List<Status> getStatusList() {
        statusList = em.createQuery("select s from Status s").getResultList();
        return statusList;
    }

    /**
     * @param statusList the statusList to set
     */
    public void setStatusList(List<Status> statusList) {
        this.statusList = statusList;
    }

    /**
     * @return the audit
     */
    public Audit getAudit() {
        return audit;
    }

    /**
     * @param audit the audit to set
     */
    public void setAudit(Audit audit) {
        this.audit = audit;
    }

    /**
     * @return the auditList
     */
    public List<Audit> getAuditList() {
        auditList = em.createQuery("select a from Audit a").getResultList();
        return auditList;
    }

    /**
     * @param auditList the auditList to set
     */
    public void setAuditList(List<Audit> auditList) {
        this.auditList = auditList;
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the accident
     */
    public Accident getAccident() {
        return accident;
    }

    /**
     * @param accident the accident to set
     */
    public void setAccident(Accident accident) {
        this.accident = accident;
    }

    public Long getAccidentListCount() {
        this.accidentListCount = ((Long) this.getEm().createNativeQuery("select count(*) from accident").getSingleResult());
        return this.accidentListCount;
    }

    /**
     * @return the accidentList
     */
    public List<Accident> getAccidentList() {
        accidentList = em.createQuery("select a from Accident a").getResultList();
        return accidentList;
    }

    /**
     * @param accidentList the accidentList to set
     */
    public void setAccidentList(List<Accident> accidentList) {
        this.accidentList = accidentList;
    }

    /**
     * @return the actors
     */
    public Actors getActors() {
        return actors;
    }

    /**
     * @param actors the actors to set
     */
    public void setActors(Actors actors) {
        this.actors = actors;
    }

    /**
     * @return the actorsList
     */
    public List<Actors> getActorsList() {
        actorsList = em.createQuery("select a from Actors a").getResultList();
        return actorsList;
    }

    /**
     * @param actorsList the actorsList to set
     */
    public void setActorsList(List<Actors> actorsList) {
        this.actorsList = actorsList;
    }

    /**
     * @return the deployment
     */
    public Deployment getDeployment() {
        return deployment;
    }

    /**
     * @param deployment the deployment to set
     */
    public void setDeployment(Deployment deployment) {
        this.deployment = deployment;
    }

    /**
     * @return the deploymentList
     */
    public List<Deployment> getDeploymentList() {
        deploymentList = em.createQuery("select d from Deployment d").getResultList();
        return deploymentList;
    }

    /**
     * @param deploymentList the deploymentList to set
     */
    public void setDeploymentList(List<Deployment> deploymentList) {
        this.deploymentList = deploymentList;
    }

    /**
     * @return the deploymentunit
     */
    public Deploymentunit getDeploymentunit() {
        return deploymentunit;
    }

    /**
     * @param deploymentunit the deploymentunit to set
     */
    public void setDeploymentunit(Deploymentunit deploymentunit) {
        this.deploymentunit = deploymentunit;
    }

    /**
     * @return the deploymentunitList
     */
    public List<Deploymentunit> getDeploymentunitList() {
        deploymentunitList = em.createQuery("select d from Deploymentunit d").getResultList();
        return deploymentunitList;
    }

    /**
     * @param deploymentunitList the deploymentunitList to set
     */
    public void setDeploymentunitList(List<Deploymentunit> deploymentunitList) {
        this.deploymentunitList = deploymentunitList;
    }

    /**
     * @return the accidentModel
     */
    public LineChartModel getAccidentModel() {
        return accidentModel;
    }

    /**
     * @param accidentModel the accidentModel to set
     */
    public void setAccidentModel(LineChartModel accidentModel) {
        this.accidentModel = accidentModel;
    }

    /**
     * @param accidentListCount the accidentListCount to set
     */
    public void setAccidentListCount(Long accidentListCount) {
        this.accidentListCount = accidentListCount;
    }

    /**
     * @return the deploymentUnitID
     */
    public List<String> getDeploymentUnitID() {
        return deploymentUnitID;
    }

    /**
     * @param deploymentUnitID the deploymentUnitID to set
     */
    public void setDeploymentUnitID(List<String> deploymentUnitID) {
        this.deploymentUnitID = deploymentUnitID;
    }

    /**
     * @return the responsibilities
     */
    public List<String> getResponsibilities() {
        return responsibilities;
    }

    /**
     * @param responsibilities the responsibilities to set
     */
    public void setResponsibilities(List<String> responsibilities) {
        this.responsibilities = responsibilities;
    }

}
