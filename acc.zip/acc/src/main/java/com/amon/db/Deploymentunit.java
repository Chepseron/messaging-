/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.amon.db;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author amon.sabul
 */
@Entity
@Table(name = "deploymentunit")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Deploymentunit.findAll", query = "SELECT d FROM Deploymentunit d"),
    @NamedQuery(name = "Deploymentunit.findByIddeploymentUnit", query = "SELECT d FROM Deploymentunit d WHERE d.iddeploymentUnit = :iddeploymentUnit"),
    @NamedQuery(name = "Deploymentunit.findByOrgname", query = "SELECT d FROM Deploymentunit d WHERE d.orgname = :orgname"),
    @NamedQuery(name = "Deploymentunit.findByDateCreated", query = "SELECT d FROM Deploymentunit d WHERE d.dateCreated = :dateCreated")})
public class Deploymentunit implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "iddeploymentUnit")
    private Integer iddeploymentUnit;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "orgname")
    private String orgname;
    @Basic(optional = false)
    @NotNull
    @Column(name = "dateCreated")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;
    @JoinColumn(name = "statusID", referencedColumnName = "idstatus")
    @ManyToOne(optional = false)
    private Status statusID;
    @JoinColumn(name = "createdBy", referencedColumnName = "idusers")
    @ManyToOne(optional = false)
    private User createdBy;
    @JoinColumn(name = "actors", referencedColumnName = "idactors")
    @ManyToOne(optional = false)
    private Actors actors;

    public Deploymentunit() {
    }

    public Deploymentunit(Integer iddeploymentUnit) {
        this.iddeploymentUnit = iddeploymentUnit;
    }

    public Deploymentunit(Integer iddeploymentUnit, String orgname, Date dateCreated) {
        this.iddeploymentUnit = iddeploymentUnit;
        this.orgname = orgname;
        this.dateCreated = dateCreated;
    }

    public Integer getIddeploymentUnit() {
        return iddeploymentUnit;
    }

    public void setIddeploymentUnit(Integer iddeploymentUnit) {
        this.iddeploymentUnit = iddeploymentUnit;
    }

    public String getOrgname() {
        return orgname;
    }

    public void setOrgname(String orgname) {
        this.orgname = orgname;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Status getStatusID() {
        return statusID;
    }

    public void setStatusID(Status statusID) {
        this.statusID = statusID;
    }

    public User getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(User createdBy) {
        this.createdBy = createdBy;
    }

    public Actors getActors() {
        return actors;
    }

    public void setActors(Actors actors) {
        this.actors = actors;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (iddeploymentUnit != null ? iddeploymentUnit.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Deploymentunit)) {
            return false;
        }
        Deploymentunit other = (Deploymentunit) object;
        if ((this.iddeploymentUnit == null && other.iddeploymentUnit != null) || (this.iddeploymentUnit != null && !this.iddeploymentUnit.equals(other.iddeploymentUnit))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.amon.db.Deploymentunit[ iddeploymentUnit=" + iddeploymentUnit + " ]";
    }
    
}
