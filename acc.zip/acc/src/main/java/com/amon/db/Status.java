/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.amon.db;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author amon.sabul
 */
@Entity
@Table(name = "status")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Status.findAll", query = "SELECT s FROM Status s"),
    @NamedQuery(name = "Status.findByIdstatus", query = "SELECT s FROM Status s WHERE s.idstatus = :idstatus"),
    @NamedQuery(name = "Status.findByName", query = "SELECT s FROM Status s WHERE s.name = :name"),
    @NamedQuery(name = "Status.findByDescription", query = "SELECT s FROM Status s WHERE s.description = :description")})
public class Status implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idstatus")
    private Integer idstatus;
    @Size(max = 100)
    @Column(name = "name")
    private String name;
    @Size(max = 45)
    @Column(name = "description")
    private String description;
    @OneToMany(mappedBy = "statusID")
    private Collection<Usergroup> usergroupCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "statusID")
    private Collection<Accident> accidentCollection;
    @JoinColumn(name = "createdBy", referencedColumnName = "idusers")
    @ManyToOne
    private User createdBy;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "statusID")
    private Collection<Deploymentunit> deploymentunitCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "statusID")
    private Collection<Actors> actorsCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "statusID")
    private Collection<Deployment> deploymentCollection;
    @OneToMany(mappedBy = "statusID")
    private Collection<User> userCollection;

    public Status() {
    }

    public Status(Integer idstatus) {
        this.idstatus = idstatus;
    }

    public Integer getIdstatus() {
        return idstatus;
    }

    public void setIdstatus(Integer idstatus) {
        this.idstatus = idstatus;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @XmlTransient
    public Collection<Usergroup> getUsergroupCollection() {
        return usergroupCollection;
    }

    public void setUsergroupCollection(Collection<Usergroup> usergroupCollection) {
        this.usergroupCollection = usergroupCollection;
    }

    @XmlTransient
    public Collection<Accident> getAccidentCollection() {
        return accidentCollection;
    }

    public void setAccidentCollection(Collection<Accident> accidentCollection) {
        this.accidentCollection = accidentCollection;
    }

    public User getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(User createdBy) {
        this.createdBy = createdBy;
    }

    @XmlTransient
    public Collection<Deploymentunit> getDeploymentunitCollection() {
        return deploymentunitCollection;
    }

    public void setDeploymentunitCollection(Collection<Deploymentunit> deploymentunitCollection) {
        this.deploymentunitCollection = deploymentunitCollection;
    }

    @XmlTransient
    public Collection<Actors> getActorsCollection() {
        return actorsCollection;
    }

    public void setActorsCollection(Collection<Actors> actorsCollection) {
        this.actorsCollection = actorsCollection;
    }

    @XmlTransient
    public Collection<Deployment> getDeploymentCollection() {
        return deploymentCollection;
    }

    public void setDeploymentCollection(Collection<Deployment> deploymentCollection) {
        this.deploymentCollection = deploymentCollection;
    }

    @XmlTransient
    public Collection<User> getUserCollection() {
        return userCollection;
    }

    public void setUserCollection(Collection<User> userCollection) {
        this.userCollection = userCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idstatus != null ? idstatus.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Status)) {
            return false;
        }
        Status other = (Status) object;
        if ((this.idstatus == null && other.idstatus != null) || (this.idstatus != null && !this.idstatus.equals(other.idstatus))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.amon.db.Status[ idstatus=" + idstatus + " ]";
    }
    
}
