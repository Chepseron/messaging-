/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.amon.db;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author amon.sabul
 */
@Entity
@Table(name = "actors")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Actors.findAll", query = "SELECT a FROM Actors a"),
    @NamedQuery(name = "Actors.findByIdactors", query = "SELECT a FROM Actors a WHERE a.idactors = :idactors"),
    @NamedQuery(name = "Actors.findByNames", query = "SELECT a FROM Actors a WHERE a.names = :names"),
    @NamedQuery(name = "Actors.findByDateCreated", query = "SELECT a FROM Actors a WHERE a.dateCreated = :dateCreated")})
public class Actors implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idactors")
    private Integer idactors;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "names")
    private String names;
    @Basic(optional = false)
    @NotNull
    @Column(name = "dateCreated")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "actors")
    private Collection<Deploymentunit> deploymentunitCollection;
    @JoinColumn(name = "statusID", referencedColumnName = "idstatus")
    @ManyToOne(optional = false)
    private Status statusID;
    @JoinColumn(name = "createdBy", referencedColumnName = "idusers")
    @ManyToOne(optional = false)
    private User createdBy;

    public Actors() {
    }

    public Actors(Integer idactors) {
        this.idactors = idactors;
    }

    public Actors(Integer idactors, String names, Date dateCreated) {
        this.idactors = idactors;
        this.names = names;
        this.dateCreated = dateCreated;
    }

    public Integer getIdactors() {
        return idactors;
    }

    public void setIdactors(Integer idactors) {
        this.idactors = idactors;
    }

    public String getNames() {
        return names;
    }

    public void setNames(String names) {
        this.names = names;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    @XmlTransient
    public Collection<Deploymentunit> getDeploymentunitCollection() {
        return deploymentunitCollection;
    }

    public void setDeploymentunitCollection(Collection<Deploymentunit> deploymentunitCollection) {
        this.deploymentunitCollection = deploymentunitCollection;
    }

    public Status getStatusID() {
        return statusID;
    }

    public void setStatusID(Status statusID) {
        this.statusID = statusID;
    }

    public User getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(User createdBy) {
        this.createdBy = createdBy;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idactors != null ? idactors.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Actors)) {
            return false;
        }
        Actors other = (Actors) object;
        if ((this.idactors == null && other.idactors != null) || (this.idactors != null && !this.idactors.equals(other.idactors))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.amon.db.Actors[ idactors=" + idactors + " ]";
    }
    
}
